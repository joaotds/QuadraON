<?php

require_once(__DIR__ . "/Controller.php");
require_once(__DIR__ . "/../service/QuadraService.php");


class QuadraController extends Controller {
    
    private $quadraService;

    public function __construct()
    {

        //Verificar se o usuário está logado
        if(! $this->usuarioEstaLogado())
            return;

        $this->quadraService = new QuadraService();

        //Tratar a ação solicitada no parâmetro "action"
        $this->handleAction();
    }

    protected function create() {

        //TODO puxar os tipos de quadro do banco
        $dados["quadras"]['tipoQuadras'] = ['GRAMADO', 'SINTETICO', 'QUADRA', 'AREIA'];

        $this->loadView("quadra/quadra-create.php", $dados);
    }


    // Listar todas as quadras do usuário
    public function list()
    {
        $idUsuario = 1;
        $dados["quadras"] = $this->quadraService->listarQuadrasPorUsuario($idUsuario);

        $this->loadView("quadra/quadra-list.php", $dados);
    }

    // salvar quadra no banco
    public function save()
    {
        $id = $this->getIdUsuarioLogado();

        //print_r($_POST);
        $nome = $_POST["nomeQuadra"];
        $tipo = $_POST["tipoQuadra"];
        $descricao = $_POST["descricao"];
        //$endereco = $_POST["endereco"];


        $this->quadraService->criarQuadra($nome, $tipo, $descricao, $id);

        $this->list();

    }

    
    // Deletar uma quadra por ID
    public function deletarQuadra($idQuadra)
    {
        return $this->quadraService->deletarQuadra($idQuadra);
    }
}

  

//Criar o objeto do controller
new QuadraController();
