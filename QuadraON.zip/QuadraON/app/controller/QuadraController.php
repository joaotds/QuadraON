<?php

require_once(__DIR__ . "/Controller.php");
require_once(__DIR__ . "/../service/QuadraService.php");


class QuadraController extends Controller {
    
    private $quadraService;

    public function __construct()
    {
        $this->quadraService = new QuadraService();

        //Tratar a ação solicitada no parâmetro "action"
        $this->handleAction();
    }

    // Listar todas as quadras do usuário
    public function list()
    {
        $idUsuario = 1;
        $dados["quadras"] = $this->quadraService->listarQuadrasPorUsuario($idUsuario);

        $this->loadView("quadra/quadra-list.php", $dados);
    }

    // Criar uma nova quadra
    public function criarQuadra($dados)
    {
        if (!isset($dados['tipo'], $dados['descricao'], $dados['idUsuario'])) {
            throw new Exception("Dados incompletos para criar quadra.");
        }

        return $this->quadraService->criarQuadra(
            $dados['tipo'],
            $dados['descricao'],
            $dados['idUsuario']
        );
    }

    // Deletar uma quadra por ID
    public function deletarQuadra($idQuadra)
    {
        return $this->quadraService->deletarQuadra($idQuadra);
    }
}

//Criar o objeto do controller
new QuadraController();
