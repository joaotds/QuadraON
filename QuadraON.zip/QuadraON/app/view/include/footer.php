<!-- Footer -->
<footer class="text-center text-white" style="background-color: #222; margin-top: 10px;">
    <div class="p-4">
        © 2023 Copyright:
        <a class="text-reset fw-bold" href="https://foz.ifpr.edu.br" target="_blank" style="color: #55bb77;">
            IFPR (Campus Foz do Iguaçu)
        </a>
    </div>
</footer>

<!-- BOOTSTRAP: scripts requeridos pelo framework -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

<!-- Fecha as tags BODY e HTML -->
</body>
</html>
